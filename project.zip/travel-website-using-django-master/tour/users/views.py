from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import UserRegisterForm


